# RSEA-MVGNN
Code for "RSEA_MVGNN__Multi_View_Graph_Neural_Network_with_Reliable_Structural_Enhancement_and_Aggregation" 

## Running Conditions
python==3.9.0 <br />
torch==2.1.0 <br />
numpy==1.26.0  <br />
pandas==2.1.1  <br />
scipy==1.11.3  <br />
tensorly==0.5.1  <br />
scikit-learn==1.3.1  <br />
tensorly==0.8.1  <br />

## Example
python main.py



